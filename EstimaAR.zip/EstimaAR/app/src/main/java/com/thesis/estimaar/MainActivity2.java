package com.thesis.estimaar;

import android.annotation.SuppressLint;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.tensorflow.lite.Interpreter;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;
import java.text.DecimalFormat;

public class MainActivity2 extends AppCompatActivity {

    EditText areaEditText, floorsEditText, roomsEditText, windowsEditText, doorsEditText;
    Spinner unitOfMeasurementSpinner;
    Button calculateButton;
    TextView totalCostTextView, cementCostTextView, sandCostTextView, gravelCostTextView, calculationHistoryTextView;
    List<String> calculationHistory = new ArrayList<>();
    Interpreter interpreter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        //UI components
        areaEditText = findViewById(R.id.area);
        floorsEditText = findViewById(R.id.floors);
        roomsEditText = findViewById(R.id.rooms);
        windowsEditText = findViewById(R.id.windows);
        doorsEditText = findViewById(R.id.doors);
        unitOfMeasurementSpinner = findViewById(R.id.unitOfMeasurementSpinner);
        calculateButton = findViewById(R.id.calculateButton);
        totalCostTextView = findViewById(R.id.totalCostTextView);
        cementCostTextView = findViewById(R.id.cementCostTextView);
        sandCostTextView = findViewById(R.id.sandCostTextView);
        gravelCostTextView = findViewById(R.id.gravelCostTextView);
        calculationHistoryTextView = findViewById(R.id.calculationHistoryTextView);
        // Set up calculate button
        calculateButton.setOnClickListener(v -> calculateCost());

        // Load TensorFlow Lite model
        try {
            interpreter = new Interpreter(loadModelFile(), null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private MappedByteBuffer loadModelFile() throws IOException {
        AssetManager assetManager = getAssets();
        AssetFileDescriptor fileDescriptor = assetManager.openFd("random_forest.tflite");
        try (FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor())) {
            FileChannel fileChannel = inputStream.getChannel();
            long startOffset = fileDescriptor.getStartOffset();
            long declaredLength = fileDescriptor.getDeclaredLength();
            return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
        }
    }
    @SuppressLint("SetTextI18n")
    private void calculateCost() {
        try {
            //input values
            double area = Double.parseDouble(areaEditText.getText().toString());
            int floors = Integer.parseInt(floorsEditText.getText().toString());
            int rooms = Integer.parseInt(roomsEditText.getText().toString());
            int windows = Integer.parseInt(windowsEditText.getText().toString());
            int doors = Integer.parseInt(doorsEditText.getText().toString());
            // Check if the unit of measurement is in square feet
            if (unitOfMeasurementSpinner.getSelectedItem().toString().equals("ft^2")) {
                // Convert area from square feet to square meters
                area = area / 10.7639; // 1 square meter = 10.7639 square feet
            }
            //input data for the TensorFlow Lite model
            float[][] input = new float[1][5];
            input[0][0] = (float) area;
            input[0][1] = floors;
            input[0][2] = rooms;
            input[0][3] = windows;
            input[0][4] = doors;

            float[][] output = new float[1][1];
            interpreter.run(input, output);

            // Retrieve predicted costs
            float totalCost = output[0][0];

            float cementCost = totalCost * 0.1f;  // Assuming 10% of total cost for cement
            float sandCost = totalCost * 0.2f;    // Assuming 20% of total cost for sand
            float gravelCost = totalCost * 0.3f;  // Assuming 30% of total cost for gravel


            DecimalFormat decimalFormat = new DecimalFormat("#,###");

            String formattedTotalCost = decimalFormat.format(totalCost);
            String formattedCementCost = decimalFormat.format(cementCost);
            String formattedSandCost = decimalFormat.format(sandCost);
            String formattedGravelCost = decimalFormat.format(gravelCost);


            totalCostTextView.setText("Total Cost: ₱" + formattedTotalCost);
            cementCostTextView.setText("Cement Cost: ₱" + formattedCementCost);
            sandCostTextView.setText("Sand Cost: ₱" + formattedSandCost);
            gravelCostTextView.setText("Gravel Cost: ₱" + formattedGravelCost);

            String calculationResult = "Calculation result: Total Cost - ₱" + formattedTotalCost;
            calculationHistory.add(calculationResult);

            // Update the calculation history
            updateCalculationHistory();
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("CalculationError", "Error in calculateCost: " + e.getMessage(), e);
            totalCostTextView.setText("An error occurred during calculation.");
        }
    }
    private void updateCalculationHistory() {
        StringBuilder historyText = new StringBuilder("\n");
        for (String calculation : calculationHistory) {
            historyText.append(calculation).append("\n");
        }
        calculationHistoryTextView.setText(historyText.toString());
    }
}
